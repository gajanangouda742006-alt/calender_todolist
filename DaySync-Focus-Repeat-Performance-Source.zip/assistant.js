function escapeHtml(value = '') {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

export function renderAssistantPage(state = {}) {
  const messages = Array.isArray(state.assistantMessages) && state.assistantMessages.length ? state.assistantMessages : [
    { role: 'assistant', text: "I'm Sahra, your AI assistant. I can help you manage tasks, events, and your progress." },
  ];
  const disabled = state.assistantLoading ? 'disabled' : '';
  const userInitial = String(state.user?.name || 'Sahra').match(/[A-Za-z]/)?.[0]?.toUpperCase() || 'S';

  return `
    <section class="screen assistant-screen">
      <header class="assistant-header glass-card page-fixed-header">
        <div class="assistant-header-row">
          
          <div class="assistant-brand">
            <div class="assistant-mark"><img class="sahra-logo" src="/images/sahra.png" alt="Sahra logo" width="48" height="48" /></div>
            <div class="assistant-title">
              <h1>Sahra</h1>
              <span>AI ASSISTANT:</span>
            </div>
          </div>
          <button class="assistant-clear-btn" type="button" data-action="clear-assistant-chat" aria-label="Clear chat">🗑 Clear</button>
        </div>
      </header>

      <div class="assistant-chat">
        ${messages.map((message) => {
          const isUser = message.role === 'user';
          const isSystem = message.role === 'system';
          if (isSystem) {
            return `
              <div class="assistant-system-row" role="status" aria-live="polite">
                <div class="assistant-system-note">${escapeHtml(message.text)}</div>
              </div>
            `;
          }
          return `
            <div class="chat-row ${isUser ? 'user-row' : 'assistant-row'}">
              ${!isUser ? '<div class="chat-avatar bot-avatar">🤖</div>' : ''}
              <div class="message-bubble ${isUser ? 'user-bubble' : 'assistant-bubble'}">${escapeHtml(message.text)}</div>
              ${isUser ? `<div class="chat-avatar user-avatar" aria-label="Your profile">${userInitial}</div>` : ''}
            </div>
            ${!isUser && message.retryRequestId ? `<div class="chat-row assistant-row"><div class="chat-avatar bot-avatar">🤖</div><button class="link-btn" type="button" data-assistant-retry="${escapeHtml(message.retryRequestId)}" data-retry-message="${escapeHtml(message.retryMessage || '')}" ${disabled}>Retry request</button></div>` : ''}
          `;
        }).join('')}

        ${state.assistantLoading ? '<div class="message-time">Sahra is thinking...</div>' : ''}
        <div class="assistant-scroll-anchor" aria-hidden="true"></div>
      </div>

      <div class="assistant-composer assistant-fixed-composer">
        <!-- Replace your old mic emoji/icon with this -->
    <button type="button" data-action="toggle-mic" style="background: transparent; border: none; padding: 0; cursor: pointer; display: flex; align-items: center; justify-content: center;">
    <img src="mic.png" alt="Mic" class="mic-icon" id="chat-mic-img" style="width: 45px; height: 45px; object-fit: contain;">
    </button>
        <input class="assistant-input" type="text" placeholder="Type a message or speak..." aria-label="Type a message" ${disabled} />
        <button class="composer-send" type="button" aria-label="Send message" ${disabled}>➤</button>
      </div>
    </section>
  `;
}
