import { Capacitor } from '@capacitor/core';
import { CapacitorSQLite, SQLiteConnection } from '@capacitor-community/sqlite';

const DATABASE_NAME = 'sahra_local';
const DATABASE_VERSION = 1;

const COLLECTIONS = [
  'events',
  'tasks',
  'moods',
  'habits',
  'goals',
  'reminders',
  'notes',
  'habitLogs',
  'expenses',
  'subscriptions',
  'assets',
  'transactions',
  'syncOutbox',
  'syncIdMap',
  'profileCache',
  'goalAchievements'
];

const PROFILE_KEY = 'sahra.local.profile';
const RECORDS_PREFIX = 'sahra.local.records.';
const sqlite = new SQLiteConnection(CapacitorSQLite);

let databasePromise = null;

function isNative() {
  return Boolean(Capacitor.isNativePlatform());
}

function validateCollection(collection) {
  const valid = COLLECTIONS.includes(collection) ||
    /^acct_[A-Za-z0-9_-]{1,128}__(events|tasks|moods|habits|goals|reminders|notes|habitLogs|expenses|subscriptions|assets|transactions|syncOutbox|syncIdMap|profileCache|goalAchievements)$/.test(collection);
  if (!valid) throw new Error(`Unsupported local collection: ${collection}`);
}

// Account-scoped collections prevent one signed-in user's cached records from
// being shown to another account on the same device. Legacy unscoped records
// are intentionally not auto-assigned to an account.
export function accountCollection(accountId, collection) {
  if (!COLLECTIONS.includes(collection) || !accountId) throw new Error('Account and valid collection are required.');
  const safeId = String(accountId).replace(/[^A-Za-z0-9_-]/g, '_').slice(0, 128);
  if (!safeId) throw new Error('Invalid account identifier.');
  return `acct_${safeId}__${collection}`;
}

function parseJson(value, fallback) {
  try {
    return JSON.parse(value);
  } catch {
    return fallback;
  }
}

function normalizeRecord(record) {
  if (!record || typeof record !== 'object' || Array.isArray(record)) {
    throw new Error('A record must be an object.');
  }

  const originalId = record.id ?? record._id;
  const id = originalId == null
    ? (globalThis.crypto?.randomUUID?.() ??
       `${Date.now()}-${Math.random().toString(36).slice(2)}`)
    : String(originalId);

  return { ...record, id };
}

async function openDatabase() {
  if (!isNative()) {
    throw new Error('Native SQLite is only available on a native device.');
  }

  const consistency = await sqlite.checkConnectionsConsistency();
  const existing = await sqlite.isConnection(DATABASE_NAME, false);

  let db;

  if (existing.result) {
    db = await sqlite.retrieveConnection(DATABASE_NAME, false);
  } else {
    db = await sqlite.createConnection(
      DATABASE_NAME,
      false,
      'no-encryption',
      DATABASE_VERSION,
      false
    );
  }

  const openStatus = await db.isDBOpen();
  if (!openStatus.result) {
    await db.open();
  }

  await db.execute(`
    CREATE TABLE IF NOT EXISTS records (
      collection TEXT NOT NULL,
      id TEXT NOT NULL,
      payload TEXT NOT NULL,
      updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY (collection, id)
    );

    CREATE INDEX IF NOT EXISTS idx_records_collection
    ON records (collection);

    CREATE TABLE IF NOT EXISTS profile (
      profile_key TEXT PRIMARY KEY,
      payload TEXT NOT NULL
    );
  `);

  return db;
}

async function getDatabase() {
  if (!databasePromise) {
    databasePromise = openDatabase().catch((error) => {
      databasePromise = null;
      throw error;
    });
  }

  return databasePromise;
}

export async function initializeLocalDatabase() {
  if (!isNative()) {
    return { driver: 'localStorage', collections: [...COLLECTIONS] };
  }

  await getDatabase();
  return { driver: 'sqlite', collections: [...COLLECTIONS] };
}

export function getLocalCollections() {
  return [...COLLECTIONS];
}

export async function getCollection(collection) {
  validateCollection(collection);

  if (!isNative()) {
    return parseJson(
      localStorage.getItem(`${RECORDS_PREFIX}${collection}`) || '[]',
      []
    );
  }

  const db = await getDatabase();
  const result = await db.query(
    'SELECT payload FROM records WHERE collection = ? ORDER BY updated_at ASC',
    [collection]
  );

  return (result.values || []).map((row) => parseJson(row.payload, null))
    .filter((record) => record !== null);
}

export async function saveRecord(collection, record) {
  validateCollection(collection);
  const normalized = normalizeRecord(record);

  if (!isNative()) {
    const records = await getCollection(collection);
    const index = records.findIndex((item) => String(item.id ?? item._id) === normalized.id);

    if (index >= 0) {
      records[index] = { ...records[index], ...normalized };
    } else {
      records.push(normalized);
    }

    localStorage.setItem(`${RECORDS_PREFIX}${collection}`, JSON.stringify(records));
    return normalized;
  }

  const db = await getDatabase();
  await db.run(
    `INSERT INTO records (collection, id, payload)
     VALUES (?, ?, ?)
     ON CONFLICT(collection, id) DO UPDATE SET
       payload = excluded.payload,
       updated_at = CURRENT_TIMESTAMP`,
    [collection, normalized.id, JSON.stringify(normalized)]
  );

  return normalized;
}

export async function deleteRecord(collection, id) {
  validateCollection(collection);
  const recordId = String(id);

  if (!isNative()) {
    const records = await getCollection(collection);
    const remaining = records.filter(
      (item) => String(item.id ?? item._id) !== recordId
    );

    localStorage.setItem(`${RECORDS_PREFIX}${collection}`, JSON.stringify(remaining));
    return;
  }

  const db = await getDatabase();
  await db.run(
    'DELETE FROM records WHERE collection = ? AND id = ?',
    [collection, recordId]
  );
}

export async function getLocalProfile() {
  if (!isNative()) {
    return parseJson(localStorage.getItem(PROFILE_KEY) || 'null', null);
  }

  const db = await getDatabase();
  const result = await db.query(
    'SELECT payload FROM profile WHERE profile_key = ?',
    ['profile']
  );

  return result.values?.length
    ? parseJson(result.values[0].payload, null)
    : null;
}

export async function saveLocalProfile(profile) {
  if (!profile || typeof profile !== 'object' || Array.isArray(profile)) {
    throw new Error('Profile must be an object.');
  }

  if (!isNative()) {
    localStorage.setItem(PROFILE_KEY, JSON.stringify(profile));
    return profile;
  }

  const db = await getDatabase();
  await db.run(
    `INSERT INTO profile (profile_key, payload)
     VALUES (?, ?)
     ON CONFLICT(profile_key) DO UPDATE SET payload = excluded.payload`,
    ['profile', JSON.stringify(profile)]
  );

  return profile;
}
