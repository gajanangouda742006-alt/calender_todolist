DaySync Weather + Mobile Keyboard Patch

Extract this ZIP into the project root: P:\MyProjects\calender_todolist
Choose Extract Here and allow overwriting. The archive contains project-relative paths.

Files:
- app.js: detect device location services disabled using native error codes/messages; show Enable Location; retry weather after returning from Android Settings; coordinate keyboard state with Capacitor events.
- style.css: make Add Event and other entry modals independently scrollable while the keyboard is open.
- scripts/mobile-entry.js: handle Capacitor keyboardDidShow/keyboardDidHide and keep focused inputs visible.
- android/app/src/main/java/com/sahra/lifecalendar/MainActivity.java and DaySyncSettingsPlugin.java: register/provide Android app, location and notification settings intents.

Build (PowerShell from project root):
$env:SAHRA_API_BASE_URL = "https://calender-todolist.onrender.com"
node --check .\app.js
node --check .\scripts\mobile-entry.js
node .\scripts\build-web.js
npm run mobile:stage
npx cap sync android
cd .\android
.\gradlew.bat assembleDebug

Test on a real Android device. Native Settings and keyboard behavior require device testing. No backend/database files are changed.
